# Hololive-Countdown
### How to use (website)

1. Create a browser source
2. Set url to `https://aknownconstant.github.io/hololive-countdown/Kiara-Heart-Challenger (Test)/`
3. Done

### How to use (offline)

1. Download as a zip by pressing the green "code" button
2. Extract the downloaded zip file (Right click -> Extract All)
3. Create a browser source
4. Check the "Local file" checkbox
5. Browse and select the `index.html`file in the extracted folder (might show up as `index` if you have file extensions hidden)
6. Make sure that `index.html` and the image (`background.png`) are in the same folder
7. Done

### Troubleshooting

#### The background is not transparent
Copy the following into the "Custom CSS" field.
`body { background-color: rgba(0, 0, 0, 0); margin: 0px auto; overflow: hidden; }`

#### The text is not in the correct position
Make the browser source wider.
